# ext-theme-access/sass/var

This folder contains variable declaration files named by their component class.
